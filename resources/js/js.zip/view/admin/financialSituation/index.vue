<template>
    <div  :class="['page-wrapper',this.$i18n.locale == 'ar'? 'page-wrapper-ar':'']">
        <div class="content container-fluid">

            <!-- Page Header -->
            <div class="page-header">
                <div class="row align-items-center">
                    <div class="col">
                        <h3 class="page-title">{{ $t('global.financialSituation') }}</h3>
                        <ul class="breadcrumb">
                            <li class="breadcrumb-item">
                                <router-link :to="{name: 'dashboard'}">
                                    {{ $t('dashboard.Dashboard') }}
                                </router-link>
                            </li>
                            <li class="breadcrumb-item active">{{ $t('global.financialSituation') }}</li>
                        </ul>
                    </div>

                </div>
            </div>
            <!-- /Page Header -->
            <!-- Table -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <loader v-if="loading"/>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table mb-0">
                                    <thead>
                                    <tr>
                                        <th>{{ $t('global.type') }}</th>
                                        <th>{{ $t('global.Debit') }} / {{$t('global.lena')}}</th>
                                        <th>{{ $t('global.Creditor')}} / {{$t('global.alina')}}</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <tr>
                                        <td>{{$t('store.store')}}</td>
                                        <td v-if="stores >= 0">{{ stores }}</td>
                                        <td v-else > ---</td>

                                        <td v-if="stores < 0">{{ stores }}</td>
                                        <td v-else > ---</td>

                                    </tr>

                                    <tr>
                                        <td>{{$t('sidebar.supplier')}}</td>
                                        <td v-if="supplier >= 0">{{ supplier }}</td>
                                        <td v-else > ---</td>

                                        <td v-if="supplier < 0">{{ supplier }}</td>
                                        <td v-else > ---</td>
                                    </tr>
                                    <tr>
                                        <td>{{$t('sidebar.client')}}</td>
                                        <td v-if="client >= 0">{{ client }}</td>
                                        <td v-else > ---</td>

                                        <td v-if="client < 0">{{ client }}</td>
                                        <td v-else > ---</td>
                                    </tr>
                                    <tr>
                                        <td>{{$t('global.treasuries')}}</td>
                                        <td v-if="treasury >= 0">{{ treasury }}</td>
                                        <td v-else > ---</td>

                                        <td v-if="treasury < 0">{{ treasury }}</td>
                                        <td v-else > ---</td>
                                    </tr>
                                    <tr>
                                        <td>{{$t('global.capitalOwnerAccount')}}</td>
                                        <td v-if="capital >= 0">{{ capital }}</td>
                                        <td v-else > ---</td>

                                        <td v-if="capital < 0">{{ capital }}</td>
                                        <td v-else > ---</td>
                                    </tr>

                                    <tr :class="[endTotal < 0 ? 'read_error': 'green-success']">
                                        <td>{{$t('global.totals')}}</td>
                                        <td>{{ totalDebit }}</td>
                                        <td>{{ totalCreditor }}</td>
                                    </tr>

                                    <tr :class="[endTotal < 0 ? 'read_error': 'green-success']">
                                        <td>{{$t('global.elsafy')}}</td>
                                        <td>{{ endTotal }}</td>
                                        <td></td>
                                    </tr>

                                    <tr>
                                        <td>{{$t('treasury.Expenses')}}</td>
                                        <td>{{ expense }}</td>
                                    </tr>

                                    </tbody>

                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- /Table -->
        </div>
        <!-- /Page Wrapper -->
    </div>
</template>

<script>
import {onMounted, watch, ref,computed} from "vue";
import {useStore} from "vuex";
import adminApi from "../../../api/adminAxios";
import {useI18n} from 'vue-i18n';

export default {
    name: "index",
    setup() {
        const {t} = useI18n({});

        let stores = ref(0);
        let supplier = ref(0);
        let client = ref(0);
        let treasury = ref(0);
        let capital = ref(0);
        let totalDebit = ref(0);
        let totalCreditor = ref(0);
        let endTotal = ref(0);
        let expense = ref(0);
        let loading = ref(false);
        const search = ref('');
        let store = useStore();

        let permission = computed(() => store.getters['authAdmin/permission']);

        let getFinancials = () => {
            loading.value = true;

            adminApi.get(`/v1/dashboard/financialSituation`)
                .then((res) => {
                    let l = res.data.data;
                    console.log(l);
                    stores.value = parseFloat(l.store).toFixed(2) ;
                    supplier.value = parseFloat(l.supplier).toFixed(2) ;
                    client.value = parseFloat(l.client).toFixed(2) ;
                    treasury.value = parseFloat(l.treasury).toFixed(2) ;
                    capital.value = parseFloat(l.capital).toFixed(2) ;
                    totalDebit.value = parseFloat(l.totalDebit).toFixed(2) ;
                    totalCreditor.value = parseFloat(l.totalCreditor).toFixed(2) ;
                    endTotal.value = totalDebit.value - totalCreditor.value;
                    expense.value = parseFloat(l.expense).toFixed(2) ;
                })
                .catch((err) => {
                    console.log(err.response.data);
                })
                .finally(() => {
                    loading.value = false;
                });
        }

        onMounted(() => {
            getFinancials();
        });

        watch(search, (search, prevSearch) => {
            if (search.length >= 0) {
                getFinancials();
            }
        });

        return { loading, getFinancials, search,permission,stores,supplier,client,treasury,capital,totalDebit,totalCreditor,expense,endTotal};

    },
    data() {
        return {
            locale: localStorage.getItem("langAdmin")
        }
    }
}
</script>

<style scoped>
.card {
    position: relative;
}

.btn-custom {
    width: 30%;
}

.custom {
    border: 1px solid #D7D7D7;
    padding: 2px;
    border-radius: 5px;
    width: 35%;
}

.btn {
    color: #fff;
}
.hover:hover{
    border: 2px solid;
    padding: 3px;
    border-radius: 7px;
}
.read_error{
    background: red;
    color: #dee2e6;
}
.green-success{
    background: green;
    color: #dee2e6;
}

</style>
