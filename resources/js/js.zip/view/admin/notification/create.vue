<template>
    <div  :class="['page-wrapper',this.$i18n.locale == 'ar'? 'page-wrapper-ar':'']">

        <div class="content container-fluid">

            <notifications :position="'top left'"  />
            <!-- Page Header -->
            <div class="page-header">
                <div class="row align-items-center">
                    <div class="col">
                        <h3 class="page-title">{{$t('global.addNotificationApp')}}</h3>
                        <ul class="breadcrumb">
                            <li class="breadcrumb-item">
                                <router-link :to="{name: 'dashboard'}">
                                    {{ $t('dashboard.Dashboard') }}
                                </router-link>
                            </li>
                            <li class="breadcrumb-item active">{{$t('global.addNotificationApp')}}</li>
                        </ul>
                    </div>
                </div>
            </div>
            <!-- /Page Header -->
            <!-- Table -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <loader v-if="loading" />
                        <div class="card-body">
                            <div class="row">
                                <div class="col-sm">
                                    <div class="alert alert-danger text-center" v-if="errors['title']">{{ errors['title'][0] }}<br /> </div>
                                    <div class="alert alert-danger text-center" v-if="errors['notification']">{{ errors['notification'][0] }}<br /> </div>
                                    <div class="alert alert-danger text-center" v-if="errors['product_id']">{{ errors['product_id'][0] }}<br /> </div>
                                    <form @submit.prevent="storeJob" class="needs-validation">
                                        <div class="form-row row">
                                            <div class="col-md-6 mb-3">
                                                <label for="validationCustom01">{{$t('global.Title')}}</label>
                                                <input type="text" class="form-control"
                                                       v-model.trim="v$.title.$model"
                                                       id="validationCustom01"
                                                       :placeholder="$t('global.Title')"
                                                       :class="{'is-invalid':v$.title.$error,'is-valid':!v$.title.$invalid}"
                                                >
                                                <div class="valid-feedback">{{$t('global.LooksGood')}}</div>
                                                <div class="invalid-feedback">
                                                    <span v-if="v$.title.required.$invalid">{{$t('global.NameIsRequired')}}<br /> </span>
                                                    <span v-if="v$.title.minLength.$invalid">{{$t('global.NameIsMustHaveAtLeast')}} {{ v$.title.minLength.$params.min }} {{$t('global.Letters')}} <br /></span>
                                                    <span v-if="v$.title.maxLength.$invalid">{{$t('global.NameIsMustHaveAtMost')}} {{ v$.title.maxLength.$params.max }} {{$t('global.Letters')}} </span>
                                                </div>
                                            </div>
                                            <div class="col-md-6 mb-3 position-relative">
                                                <label>{{ $t('global.ChooseProduct') }}</label>
                                                <input type="text"
                                                       class="form-control mb-1 input-Sender"
                                                       v-model="search"
                                                       @input="searchProduct"
                                                       @blur="isButton = true"
                                                       @focus="searchProduct"
                                                       autofocus
                                                       :placeholder="$t('treasury.Search')"
                                                >
                                                <ul class="dropdown-search sender-search" v-if="dropDownSenders.length">
                                                    <li
                                                        class="Sender"
                                                        v-for="(dropDownSender,index) in dropDownSenders"
                                                        :key="index"
                                                        @click="showProduct(index)"
                                                        @mouseenter="senderHover"
                                                    >
                                                        {{dropDownSender.name }}
                                                    </li>
                                                </ul>

                                                <input type="text"
                                                       :class="['form-control',{'is-invalid':v$.product_id.$error,'is-valid':!v$.product_id.$invalid}]"
                                                       disabled
                                                       v-model="nameSender"
                                                >
                                                <div class="valid-feedback">{{$t('global.LooksGood')}}</div>
                                                <div class="invalid-feedback">
                                                </div>

                                            </div>

                                            <div class="col-md-12 mb-3">
                                                <label>{{$t('global.theNotification')}}</label>
                                                <textarea rows="4" cols="5" v-model.trim="v$.notification.$model" :class="['form-control text-height',{'is-invalid':v$.notification.$error,'is-valid':!v$.notification.$invalid}]" :placeholder="$t('global.theNotification')"></textarea>
                                                <div class="valid-feedback">{{$t('global.LooksGood')}}</div>
                                                <div class="invalid-feedback">
                                                    <span v-if="v$.notification.required.$invalid">{{$t('global.ThisFieldIsRequired')}}<br /> </span>
                                                    <span v-if="v$.notification.minLength.$invalid">{{$t('global.IsMustHaveAtLeast')}} {{ v$.notification.minLength.$params.min }} {{$t('global.Letters')}} <br /></span>
                                                </div>
                                            </div>

                                        </div>

                                        <button class="btn btn-primary" type="submit" v-if="isButton">{{$t('global.Submit')}}</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- /Table -->
        </div>
    </div>
</template>

<script>
import {computed, onMounted, reactive,toRefs,inject,ref} from "vue";
import useVuelidate from '@vuelidate/core';
import {required,minLength,between,maxLength,alpha,integer} from '@vuelidate/validators';
import adminApi from "../../../api/adminAxios";
import { notify } from "@kyvg/vue3-notification";
import {useI18n} from "vue-i18n";


export default {
    name: "create",
    data(){
        return {
            errors:{}
        }
    },
    setup(){
        const {t} = useI18n({});
        let loading = ref(false);
        let products = ref([]);
        let dropDownSenders = ref([]);
        let isButton = ref(true);

        let getProducts = () => {
            loading.value = true;

            adminApi.get(`/v1/dashboard/mobileProduct`)
                .then((res) => {
                    let l = res.data.data;
                    products.value= l.products;
                })
                .catch((err) => {
                    console.log(err.response.data);
                })
                .finally(() => {
                    loading.value = false;
                })
        }

        onMounted(() => {
            getProducts();
        });

        let addJob =  reactive({
            data:{
                title : '',
                notification:'',
                product_id:''
            },
            nameSender: '',
            search: '',
        });

        const rules = computed(() => {
            return {
                notification:{
                    required,
                    minLength: minLength(5),
                },
                title: {
                    minLength: minLength(3),
                    maxLength:maxLength(50),
                    required
                },
                product_id:{}
            }
        });
        let searchProduct = (index) => {
            dropDownSenders.value = [];
            if(addJob.search){
                let thisString = new RegExp(addJob.search,'i');
                let items = products.value.filter(e => e.name.match(thisString) || e.id == addJob.search);
                dropDownSenders.value = items.splice(0,10);
            }else{
                dropDownSenders.value = [];
            }
            isButton.value = false;
        };
        let showProduct = (index) => {
            let item = dropDownSenders.value[index];
            addJob.nameSender =  item.name;
            addJob.data.product_id = item.id;
            addJob.search = '';
            dropDownSenders.value = [];
        };
        let senderHover = (e) => {
            let items = document.querySelectorAll('.sender-search .Sender');
            items.forEach(e => e.classList.remove('active'));
            e.target.classList.add('active');
        };
        document.addEventListener('keyup',(e) => {

            if(e.keyCode == 38){ //top arrow
                if(dropDownSenders.value.length > 0){
                    let items = document.querySelectorAll('.sender-search .Sender');
                    let isTrue = false;
                    let index = null;
                    items.forEach((e,i) => {
                        if(e.classList.contains('active')) {
                            isTrue = true;
                            index = i;
                        }
                    });
                    if(isTrue && index != 0){
                        items[index].classList.remove('active');
                        items[index - 1].classList.add('active');
                    }else if(isTrue && index == 0){
                        items[index].classList.remove('active');
                        items[items.length - 1].classList.add('active');
                    }
                    if(!isTrue) items[0].classList.add('active');
                }else {
                    dropDownSenders.value = [];
                }
            };

            if(e.keyCode == 40){ //down arrow
                if(dropDownSenders.value.length > 0){
                    let items = document.querySelectorAll('.sender-search .Sender');
                    let isTrue = false;
                    let index = null;
                    items.forEach((e,i) => {
                        if(e.classList.contains('active')) {
                            isTrue = true;
                            index = i;
                        }
                    });
                    if(isTrue && index != (items.length - 1)){
                        items[index].classList.remove('active');
                        items[index + 1].classList.add('active');
                    }else if(isTrue && index == (items.length - 1)){
                        items[index].classList.remove('active');
                        items[0].classList.add('active');
                    }
                    if(!isTrue) items[items.length - 1].classList.add('active');
                }else {
                    dropDownSenders.value = [];
                }
            };

            if(e.keyCode == 13){ //enter

                if(dropDownSenders.value.length > 0){
                    let items = document.querySelectorAll('.sender-search .Sender');
                    items.forEach((e,i) => {
                        if(e.classList.contains('active')) showProduct(i);
                    });
                }else {
                    dropDownSenders.value = [];
                }
                e.target.blur();
            };

        });

        document.addEventListener('click',(e) => {
            if(dropDownSenders.value.length > 0){
                if(!e.target.classList.contains('Sender') && !e.target.classList.contains('input-Sender') && e.pointerType){
                    dropDownSenders.value = [];
                }
            }
        });


        const v$ = useVuelidate(rules,addJob.data);


        return {t,products,loading,...toRefs(addJob),v$,searchProduct,showProduct,senderHover,dropDownSenders,isButton};
    },
    methods: {
        storeJob(){
            this.v$.$validate();

            if(!this.v$.$error){

                this.loading = true;
                this.errors = {};

                adminApi.post(`/v1/dashboard/notificationApp`,this.data)
                    .then((res) => {

                        notify({
                            title: `${this.t('global.AddedSuccessfully')} <i class="fas fa-check-circle"></i>`,
                            type: "success",
                            duration: 5000,
                            speed: 2000
                        });

                        this.resetForm();
                        this.$nextTick(() => { this.v$.$reset() });
                    })
                    .catch((err) => {
                        this.errors = err.response.data.errors;
                    })
                    .finally(() => {
                        this.loading = false;
                    });

            }
        },
        resetForm(){
            this.data.title = '';
            this.data.notification = '';
            this.data.product_id = '';
            this.nameSender= '';
            this.search= '';
        }
    }
}
</script>

<style scoped>
.coustom-select {
    height: 100px;
}
.card{
    position: relative;
}
.dropdown-search{
    position: absolute;
    width: 97%;
    background-color: #fff;
    border: 1px solid #d9d3d3;
    top: 83px;
    z-index: 10;
    padding: 0;
}

.dropdown-search li{
    padding: 5px;
}

.dropdown-search li:not(:last-child){
    border-bottom: 1px solid #d9d3d3;
}

.dropdown-search li:hover{
    background-color: #f1f1f1;
    cursor: pointer;
}
.dropdown-search li.active{
    background-color: #f1f1f1;
    cursor: pointer;
}
</style>
