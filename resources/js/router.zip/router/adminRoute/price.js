import indexPrice from "../../view/admin/virtualStock/all_prices_index";
import store from "../../store/admin";

export default [
    {
        path: 'price',
        component:  {
            template:'<router-view />',
        },
        children:[
            {
                path: '',
                name: 'indexPrice',
                component: indexPrice,
                beforeEnter: (to, from,next) => {
                    let permission = store.state.authAdmin.permission;

                    if(permission.includes('price read')){
                        return next();
                    }else{
                        return next({name:'Page404'});
                    }
                    return next();
                }
            },
        ]
    },
];
