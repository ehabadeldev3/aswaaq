import financialSituation from "../../view/admin/financialSituation/index.vue";

export default [
    {
        path: 'financialSituation',
        component:  {
            template:'<router-view />',
        },
        children:[
            {
                path: '',
                name: 'financialSituation',
                component: financialSituation,
            }
        ]
    },
];
